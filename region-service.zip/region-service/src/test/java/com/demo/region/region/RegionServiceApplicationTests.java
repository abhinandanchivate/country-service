package com.demo.region.region;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegionServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
